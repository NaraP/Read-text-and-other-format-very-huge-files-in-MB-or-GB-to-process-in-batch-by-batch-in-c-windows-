﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Reflection;
using System.Windows.Forms;

namespace WindowsFormsApp.Helper
{
    public class FileHelper
    {
        /// <summary>
        /// CompareTwoListData this method is used for the parallal two list data add result data into list to write into rext file
        /// </summary>
        /// <param name="features"></param>
        /// <param name="featuresToDelete"></param>
        /// <returns></returns>
        public async Task<List<string>> CompareTwoListData(List<string> features, List<string> featuresToDelete)
        {
            List<string> listDifference = new List<string>(100000);

            var featuresTaskData = Task.Run(() =>
            {
                Parallel.ForEach(features, a =>
                {
                    var val = a.Split(',');

                    if (featuresToDelete.Contains(val[0]))
                    {
                        // featuresToDelete.Remove(val[0]);
                        listDifference.Add(a);
                    }
                    else
                    {
                        listDifference.Add(a);
                    }
                });
            });
            await featuresTaskData;

            return listDifference;
        }


        public async Task<List<string>> CompareTwoListDataForeach(List<string> features, List<string> featuresToDelete)
        {
            List<string> listDifference = new List<string>(100000);

            var featuresTaskData = Task.Run(() =>
            {
                foreach (var item1 in features)
                {
                    var val = item1.Split(',');

                    if (featuresToDelete.Contains(val[0]))
                    {
                        listDifference.Add(item1);
                    }
                    else
                    {
                        listDifference.Add(item1);
                    }
                }
            });
            await featuresTaskData;
          
            return listDifference;
        }


        /// <summary>
        /// ConvertListToDataTable this method is used for the conevrt list to datatable
        /// </summary>
        /// <param name="features"></param>
        /// <returns></returns>
        public async Task<DataTable> ConvertListToDataTable(List<string> features)
        {
            DataTable listDifference = new DataTable();

            var featuresTaskData = Task.Run(() =>
            {
                Parallel.ForEach(features, a =>
                {
                    if (!string.IsNullOrEmpty(a))
                    {
                        listDifference.Rows.Add(a);
                    }
                });
            });
            await featuresTaskData;

            return listDifference;
        }

        /// <summary>
        /// ReadFileInBatch this method is used to write data into text file and compare the two text files data
        /// </summary>
        /// <param name="featureFilePath"></param>
        /// <param name="featureToDeletePath"></param>
        /// <param name="newfilepath"></param>
        /// <returns></returns>
        public async Task<List<string>> ReadFileInBatch(string featureFilePath, string featureToDeletePath, string newfilepath)
        {
            int result = 0;
            List<string> FinalresultFeaturelist = new List<string>();

            try
            {
                int TotalRows = File.ReadLines(featureFilePath).Count(); // Count the number of rows in file with lazy load
                result = TotalRows;

                int Limit = 100000;
                DataTable featuretable = new DataTable();

                DataTable featuretableTodelete = featureToDeletePath.FileToTable(heading: true, delimiter: '\t', limit: Limit);

                List<string> featureToDeletList = featuretableTodelete.Rows.OfType<DataRow>().Select(dr => (string)dr[0]).ToList();

                List<string> resultFeaturelist = new List<string>();

                for (int Offset = 0; Offset < TotalRows; Offset += Limit)
                {
                    // Print Logs in console application
                    //string Logs = string.Format("Processing :: Rows {0} of Total {1} :: Offset {2} : Limit : {3}",
                    //    (Offset + Limit) < TotalRows ? Offset + Limit : TotalRows,
                    //    TotalRows, Offset, Limit
                    //);

                    //Console.WriteLine(Logs);

                    featuretable = featureFilePath.FileToTable(heading: true, delimiter: '\t', offset: Offset, limit: Limit);

                    //List<string> list = featuretableTodelete.Rows.OfType<DataRow>().Select(dr => (string)dr[0]).ToList();

                    List<string> featureList = featuretable.Rows.OfType<DataRow>().Select(dr => (string)dr[0]).ToList();

                    if (featureToDeletList.Count() > 0 && featureList.Count() > 0)
                    {
                        resultFeaturelist= await CompareTwoListDataForeach(featureList, featureToDeletList);
                       // resultFeaturelist = await CompareTwoListData(featureList, featureToDeletList);

                        FinalresultFeaturelist.AddRange(resultFeaturelist);
                    }
                    else
                    {
                        FinalresultFeaturelist.AddRange(featureList);
                    }
                }

                File.WriteAllText(featureToDeletePath, String.Empty);
            }
            catch (Exception ex)
            {
            }
            return FinalresultFeaturelist;
        }
    }
}
