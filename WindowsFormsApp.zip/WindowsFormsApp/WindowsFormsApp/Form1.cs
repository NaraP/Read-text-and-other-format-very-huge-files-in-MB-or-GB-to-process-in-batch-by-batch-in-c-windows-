﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp.Helper;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {
        DialogResult resultfeaturesToDelete;
        DialogResult resultfeatures;
        string fileFeature;
        string fileFeatureToDelete;

        string file1path = @"D:\\Test\\Project\\Features.txt";
        string file2path = @"D:\\Test\\Project\\FeaturesToDelete.txt";
        string newfilepath = @"D:\\Test\\Project\\newfile.txt";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnFeature_Click(object sender, EventArgs e)
        {
            resultfeatures = openFileDialog1.ShowDialog();

            if(resultfeatures == DialogResult.OK)
            {
                 fileFeature = openFileDialog1.FileName;
            }
        }

        private void btnfeatureToDelete_Click(object sender, EventArgs e)
        {
             resultfeaturesToDelete = openFileDialog1.ShowDialog();
            if (resultfeaturesToDelete == DialogResult.OK)
            {
                 fileFeatureToDelete = openFileDialog1.FileName;
            }
        }

        private async void BtnCmp_Click(object sender, EventArgs e)
        {
            try
            {
                Stopwatch sw = new Stopwatch();

                progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;

                sw.Start();

                var featuresToDeleteFilePath = fileFeatureToDelete;

                var featureFilePath = fileFeature;

                FileHelper fileHelper = new FileHelper();

                ///This would support for the huge size of the files like GBs and tested with 1.5 gb its working  fine in the batch 100000
                ///All methods are used as asyn and await, few methods applied parral foreach loop
                int result = await fileHelper.ReadFileInBatch(featureFilePath, featuresToDeleteFilePath, newfilepath);

                sw.Stop();

                MessageBox.Show(" file count " + result + " + Time Taken in milli seconds-->{0}" + sw.ElapsedMilliseconds);
                progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;

            }
            catch (Exception ex)
            {
            }
        }
    }
}
