﻿using System;
using System.IO;
using System.Linq;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string file1path = @"D:\\Test\\Project\\Features.txt";

            var featuresToDelete = File.ReadAllLines(file1path).ToList();

            for(int i=0; i<=10;i++)
            {
                File.WriteAllLines(file1path, featuresToDelete.ToArray());
            }
        }
    }
}
