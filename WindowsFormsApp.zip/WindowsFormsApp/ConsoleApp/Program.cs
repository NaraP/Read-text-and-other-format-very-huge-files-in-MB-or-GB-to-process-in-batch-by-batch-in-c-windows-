﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            List<String> finalresult = new List<string>();

            string file1path = @"D:\\Test\\Project\\Features.txt";

            var featuresToDelete = File.ReadAllLines(file1path).ToList();

            for (int i = 0; i <= 10; i++)
            {
                finalresult.AddRange(featuresToDelete);
            }

            File.WriteAllLines(file1path, finalresult.ToArray());

        }
    }
}
